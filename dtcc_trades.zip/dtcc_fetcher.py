#!/usr/bin/env python3
"""
Independent DTCC Data Fetcher
Fetches trade data from DTCC API, processes it, and saves to CSV with duplicate handling.
Handles trade modifications by replacing old trades when Original Dissemination Identifier is present.
"""

import requests
import csv
import os
import time
import logging
from datetime import datetime
from typing import Dict, List, Set, Optional
import threading
import signal
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('dtcc_fetcher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration
DTCC_API_URL = "https://pddata.dtcc.com/ppd/api/ticker/CFTC/RATES"
CSV_FILE_NAME = "dtcc_trades.csv"
FETCH_INTERVAL = 60  # seconds
MAX_RETRIES = 3
REQUEST_TIMEOUT = 30

class DTCCFetcher:
    def __init__(self, csv_file: str = CSV_FILE_NAME):
        self.csv_file = csv_file
        self.running = False
        self.thread = None
        self.existing_dissemination_ids: Set[str] = set()
        self.existing_original_dissemination_ids: Set[str] = set()
        
        # CSV field names
        self.fieldnames = [
            'Trade Time', 'Effective Date', 'Expiration Date', 'Tenor', 'Currency',
            'Rates', 'Notionals', 'Dv01', 'Frequency', 'Action Type', 'Event Type',
            'Asset Class', 'UPI Underlier Name', 'Unique Product Identifier',
            'Dissemination Identifier', 'Original Dissemination Identifier', 
            'Other Payment Type', 'Package Indicator',
            'Floating Rate Payment Frequency Period Leg2', 
            'Floating Rate Payment Frequency Period Multiplier Leg2',
            'Fixed Rate Payment Frequency Period Leg1', 
            'Fixed Rate Payment Frequency Period Multiplier Leg1',
            'Created At', 'Updated At'
        ]
        
        # Initialize CSV file if it doesn't exist
        self._initialize_csv()
        self._load_existing_ids()
        
    def _initialize_csv(self):
        """Initialize CSV file with headers if it doesn't exist"""
        if not os.path.exists(self.csv_file):
            try:
                with open(self.csv_file, 'w', newline='', encoding='utf-8') as csvfile:
                    writer = csv.DictWriter(csvfile, fieldnames=self.fieldnames)
                    writer.writeheader()
                logger.info(f"Created new CSV file: {self.csv_file}")
            except Exception as e:
                logger.error(f"Error creating CSV file: {e}")
                raise
    
    def _load_existing_ids(self):
        """Load existing dissemination IDs from CSV to track duplicates"""
        self.existing_dissemination_ids.clear()
        self.existing_original_dissemination_ids.clear()
        
        if not os.path.exists(self.csv_file):
            return
            
        try:
            with open(self.csv_file, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    # Track dissemination identifiers
                    if row.get('Dissemination Identifier'):
                        self.existing_dissemination_ids.add(row['Dissemination Identifier'])
                    
                    # Track original dissemination identifiers
                    if row.get('Original Dissemination Identifier'):
                        self.existing_original_dissemination_ids.add(row['Original Dissemination Identifier'])
            
            logger.info(f"Loaded {len(self.existing_dissemination_ids)} existing dissemination IDs")
            logger.info(f"Loaded {len(self.existing_original_dissemination_ids)} existing original dissemination IDs")
            
        except Exception as e:
            logger.error(f"Error loading existing IDs: {e}")
    
    def fetch_trade_data(self) -> Optional[Dict]:
        """Fetch trade data from DTCC API"""
        for attempt in range(MAX_RETRIES):
            try:
                logger.info(f"Fetching data from DTCC API (attempt {attempt + 1}/{MAX_RETRIES})")
                response = requests.get(DTCC_API_URL, timeout=REQUEST_TIMEOUT)
                response.raise_for_status()
                
                data = response.json()
                logger.info(f"Successfully fetched data: {len(data.get('tradeList', []))} trades")
                return data
                
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(5)  # Wait before retry
                else:
                    logger.error(f"All {MAX_RETRIES} attempts failed")
                    return None
            except Exception as e:
                logger.error(f"Unexpected error fetching data: {e}")
                return None
    
    def calculate_dv01(self, notional: str, rates: str, tenor_in_years: float) -> Optional[float]:
        """Calculate DV01 (Dollar Value of 01)"""
        try:
            # Clean and convert notional
            notional_str = str(notional).replace(',', '').replace('$', '')
            notional_val = float(notional_str) if notional_str else 0
            
            # Convert rates
            rates_val = float(rates) if rates else 0
            
            # Calculate DV01: Dv01 = Notional * Rates * Tenor / 10000
            dv01 = (notional_val * rates_val * tenor_in_years) / 10000
            return round(dv01, 2)
            
        except (ValueError, TypeError) as e:
            logger.warning(f"Error calculating DV01: {e}")
            return None
    
    def process_trades(self, trade_list: List[Dict]) -> List[Dict]:
        """Process raw trade data into structured format"""
        processed_data = []
        current_time = datetime.now()
        
        for trade in trade_list:
            try:
                # Extract basic fields
                trade_time = trade.get('eventTimestamp', '')
                effective_date = trade.get('effectiveDate', '')
                expiration_date = trade.get('expirationDate', '')
                currency = trade.get('notionalCurrencyLeg1', '')
                rates = trade.get('fixedRateLeg1', '') or trade.get('spreadLeg1', '')
                notionals = trade.get('notionalAmountLeg1', '')
                action_type = trade.get('actionType', '')
                event_type = trade.get('eventType', '')
                asset_class = trade.get('assetClass', '')
                upi_underlier_name = trade.get('uniqueProductIdentifierUnderlierName', '')
                unique_product_identifier = trade.get('uniqueProductIdentifier', '')
                dissemination_identifier = trade.get('disseminationIdentifier', '')
                original_dissemination_identifier = trade.get('originalDisseminationIdentifier', '')
                
                # Additional fields
                frequency = trade.get('Settlement currency-Leg 1', '')
                other_payment_type = trade.get('otherPaymentType', '')
                package_indicator = trade.get('packageIndicator', '')
                floating_rate_payment_frequency_period_leg2 = trade.get('floatingRatePaymentFrequencyPeriodLeg2', '')
                floating_rate_payment_frequency_period_multiplier_leg2 = trade.get('floatingRatePaymentFrequencyPeriodMultiplierLeg2', '')
                fixed_rate_payment_frequency_period_leg1 = trade.get('fixedRatePaymentFrequencyPeriodLeg1', '')
                fixed_rate_payment_frequency_period_multiplier_leg1 = trade.get('fixedRatePaymentFrequencyPeriodMultiplierLeg1', '')
                
                # Calculate tenor in years
                tenor_in_years = None
                if effective_date and expiration_date:
                    try:
                        effective_dt = datetime.strptime(effective_date, '%Y-%m-%d')
                        expiration_dt = datetime.strptime(expiration_date, '%Y-%m-%d')
                        tenor_in_years = (expiration_dt - effective_dt).days / 365.25
                    except ValueError:
                        pass
                
                # Calculate DV01
                dv01 = self.calculate_dv01(notionals, rates, tenor_in_years) if tenor_in_years else None
                
                processed_trade = {
                    'Trade Time': trade_time,
                    'Effective Date': effective_date,
                    'Expiration Date': expiration_date,
                    'Tenor': tenor_in_years,
                    'Currency': currency,
                    'Rates': rates,
                    'Notionals': notionals,
                    'Dv01': dv01,
                    'Frequency': frequency,
                    'Action Type': action_type,
                    'Event Type': event_type,
                    'Asset Class': asset_class,
                    'UPI Underlier Name': upi_underlier_name,
                    'Unique Product Identifier': unique_product_identifier,
                    'Dissemination Identifier': dissemination_identifier,
                    'Original Dissemination Identifier': original_dissemination_identifier,
                    'Other Payment Type': other_payment_type,
                    'Package Indicator': package_indicator,
                    'Floating Rate Payment Frequency Period Leg2': floating_rate_payment_frequency_period_leg2,
                    'Floating Rate Payment Frequency Period Multiplier Leg2': floating_rate_payment_frequency_period_multiplier_leg2,
                    'Fixed Rate Payment Frequency Period Leg1': fixed_rate_payment_frequency_period_leg1,
                    'Fixed Rate Payment Frequency Period Multiplier Leg1': fixed_rate_payment_frequency_period_multiplier_leg1,
                    'Created At': current_time.isoformat(),
                    'Updated At': current_time.isoformat()
                }
                
                processed_data.append(processed_trade)
                
            except Exception as e:
                logger.warning(f"Error processing trade: {e}")
                continue
        
        return processed_data
    
    def handle_trade_modifications(self, processed_trades: List[Dict]) -> List[Dict]:
        """Handle trade modifications and duplicates"""
        trades_to_add = []
        trades_to_remove = []
        
        for trade in processed_trades:
            dissemination_id = trade.get('Dissemination Identifier', '')
            original_dissemination_id = trade.get('Original Dissemination Identifier', '')
            
            # Skip if no dissemination identifier
            if not dissemination_id:
                logger.warning("Trade without dissemination identifier skipped")
                continue
            
            # Check if this is a modification (has Original Dissemination Identifier)
            if original_dissemination_id:
                # This is a modified trade - remove the old trade
                if original_dissemination_id in self.existing_dissemination_ids:
                    trades_to_remove.append(original_dissemination_id)
                    logger.info(f"Trade modification detected: {original_dissemination_id} -> {dissemination_id}")
            
            # Check for duplicates
            if dissemination_id not in self.existing_dissemination_ids:
                trades_to_add.append(trade)
                # Update tracking sets
                self.existing_dissemination_ids.add(dissemination_id)
                if original_dissemination_id:
                    self.existing_original_dissemination_ids.add(original_dissemination_id)
            else:
                logger.info(f"Duplicate trade skipped: {dissemination_id}")
        
        # Remove modified trades from CSV
        if trades_to_remove:
            self._remove_trades_from_csv(trades_to_remove)
        
        return trades_to_add
    
    def _remove_trades_from_csv(self, dissemination_ids_to_remove: List[str]):
        """Remove trades with specified dissemination IDs from CSV"""
        try:
            # Read all rows
            rows = []
            with open(self.csv_file, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                rows = list(reader)
            
            # Filter out rows to remove
            filtered_rows = [
                row for row in rows 
                if row.get('Dissemination Identifier', '') not in dissemination_ids_to_remove
            ]
            
            # Write back filtered rows
            with open(self.csv_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=self.fieldnames)
                writer.writeheader()
                writer.writerows(filtered_rows)
            
            removed_count = len(rows) - len(filtered_rows)
            logger.info(f"Removed {removed_count} modified trades from CSV")
            
            # Update tracking sets
            for id_to_remove in dissemination_ids_to_remove:
                self.existing_dissemination_ids.discard(id_to_remove)
                self.existing_original_dissemination_ids.discard(id_to_remove)
            
        except Exception as e:
            logger.error(f"Error removing trades from CSV: {e}")
    
    def append_to_csv(self, new_trades: List[Dict]):
        """Append new trades to CSV file"""
        if not new_trades:
            return
        
        try:
            with open(self.csv_file, 'a', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=self.fieldnames)
                writer.writerows(new_trades)
            
            logger.info(f"Added {len(new_trades)} new trades to {self.csv_file}")
            
        except Exception as e:
            logger.error(f"Error writing to CSV file: {e}")
    
    def run_fetch_cycle(self):
        """Run one complete fetch cycle"""
        try:
            logger.info("Starting DTCC data fetch cycle...")
            
            # Fetch data from API
            json_data = self.fetch_trade_data()
            if not json_data or 'tradeList' not in json_data:
                logger.warning("No trade data fetched or 'tradeList' not found in response")
                return
            
            trades = json_data['tradeList']
            if not trades:
                logger.info("No trades in response")
                return
            
            # Process trades
            processed_trades = self.process_trades(trades)
            logger.info(f"Processed {len(processed_trades)} trades")
            
            # Handle modifications and duplicates
            new_trades = self.handle_trade_modifications(processed_trades)
            
            # Add new trades to CSV
            if new_trades:
                self.append_to_csv(new_trades)
                logger.info(f"Added {len(new_trades)} new trades to CSV")
            else:
                logger.info("No new trades to add")
            
            logger.info("Fetch cycle completed successfully")
            
        except Exception as e:
            logger.error(f"Error in fetch cycle: {e}")
    
    def start(self):
        """Start the continuous fetching process"""
        if self.running:
            logger.warning("Fetcher is already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        logger.info(f"DTCC Fetcher started - running every {FETCH_INTERVAL} seconds")
    
    def stop(self):
        """Stop the fetching process"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("DTCC Fetcher stopped")
    
    def _run_loop(self):
        """Main loop for continuous fetching"""
        while self.running:
            try:
                self.run_fetch_cycle()
                
                # Wait for next cycle
                for _ in range(FETCH_INTERVAL):
                    if not self.running:
                        break
                    time.sleep(1)
                    
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(60)  # Wait before retrying
    
    def run_once(self):
        """Run a single fetch cycle"""
        logger.info("Running single fetch cycle...")
        self.run_fetch_cycle()

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Received shutdown signal")
    if 'fetcher' in globals():
        fetcher.stop()
    sys.exit(0)

def main():
    """Main function"""
    # Set up signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create fetcher instance
    fetcher = DTCCFetcher()
    
    try:
        if len(sys.argv) > 1 and sys.argv[1] == '--once':
            # Run once and exit
            fetcher.run_once()
        else:
            # Run continuously
            fetcher.start()
            
            # Keep main thread alive
            while fetcher.running:
                time.sleep(1)
                
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        fetcher.stop()
        logger.info("DTCC Fetcher shutdown complete")

if __name__ == "__main__":
    main()
